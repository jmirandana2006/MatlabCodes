function SistmAmortecimento()
% sistema de liberdade 
% mostra o efeito de mudan�a do amortocimento do
% sistema sobre rea�ao. 
%mx" + cx' + kx = f(omegaft) 

clear all; close all;
 
t_inicio = 0; 
t_fim   = 6;  %tempo final em segundos
interv_tempo =t_inicio:0.001:t_fim;
 
k = 40; % rigidez da mola. N/m 
m = 5;  % massa, kg
 
cr = 2*sqrt(k*m);  %amortecimento critico
 
% fprintf('Coeficiente de Amortecimento Critico do Sistema e %f\n',cr);
 
posicao_inicial = 0; 
velocidade_inicial = 0;
 
x0 = [posicao_inicial  velocidade_inicial];
 
% Agora come�a a simula mudando o amortecimento.
 
for c = 0: .5 : cr+.1*cr
 
  [t,x]=ode45(@miranda,interv_tempo,x0);    
  plot(t,x(:,1));    
  title(sprintf('Amortecimento Critico=%4.1f, Coeficiente de Amortecimento atual. =%4.1f',cr,c));   
  ylim([-.1 .9]);    
  drawnow;    
  pause(.1);
 
end
 
grid on