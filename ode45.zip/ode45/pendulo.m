function xdot=pendulo(t,x)
m=0.3;
b=0.05;
L=0.5;
%constantes
g=9.81;
%normaliza�ao
r=g/L;
k=b/(m*L);

xdot(1)=x(2);
xdot(2)=-k*x(2) - r*sin(x(1));
xdot=xdot';