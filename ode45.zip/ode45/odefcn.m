function dydt = odefcn(t,y)
A = 1;
B = 2;
dydt = zeros(2,1);
dydt(1) = y(2);
dydt(2) = (A/B)*t.*y(1)