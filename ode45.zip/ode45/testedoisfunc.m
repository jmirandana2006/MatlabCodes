clear all, close all, clc
tempo=[-1,1];
inicial=[1,1];
[t,y]=ode45(@doisfunc,tempo,inicial);
figure
plot(t,y(:,1),'k',t,y(:,2),'linewidth',1.5), 
