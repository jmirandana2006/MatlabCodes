clear all,close all, clc
tspan = [1 5];
ic = 1;
opts = odeset('RelTol',1e-2,'AbsTol',1e-4);
[t,y] = ode45(@myode,tspan, ic, opts);

plot(t,y)