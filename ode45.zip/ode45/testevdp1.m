clear all, close all, clc
[t,y] = ode45(@vdp1,[0 20],[2; 0]);
plot(t,y(:,1),'-o',t,y(:,2),'-o')
title('Solu�ao da Equa�ao van der Pol (\mu = 1) com ODE45');
xlabel('Time t');
ylabel('Solu�ao y');
legend('y_1','y_2')