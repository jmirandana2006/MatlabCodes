function dy=doisfunc(t,y)
%este representa y' = y2
%este representa y2'=-y1
dy(1)=y(2);
dy(2)=-y(1);
dy=[dy(1); dy(2)];