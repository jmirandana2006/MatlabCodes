function f=meued2nd1(t,y)
m=5;
M=10;
theta=pi/3;
L=0.3;
g=9.81;
f=[y(2);...
        ((m/(m+M))*y(2)*y(2)*sin(theta)*cos(theta)...
        -g*sin(theta)/L)/((m/(m+M))*cos(theta)*cos(theta)-1)];
