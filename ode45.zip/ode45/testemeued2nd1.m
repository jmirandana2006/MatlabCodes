clear all, close all, clc

intertempo=[0 1];
inicial=[0, pi];
[t,y]=ode45(@meued2nd1,intertempo,inicial);
plot(t,y(:,1)), title('theta')
figure
plot(t,y(:,2)), title('velocidade angular')
