% kalman filtering 
 
load initial_track  s; % y:initial data,s:data with noise 
T=0.1; 
 
% yp denotes the sample value of position 
% yv denotes the sample value of velocity 
% Y=[yp(n);yv(n)]; 
% error deviation caused by the random acceleration  
% known data 
Y=zeros(2,200); 
Y0=[0;1]; 
Y(:,1)=Y0; 
A=[1 T 
    0 1];           
B=[1/2*(T)^2 T]'; 
H=[1 0]; 
 
C0=[0 0 
    0 1];    %?????? 
C=[C0 zeros(2,2*199)]; 
Q=(0.25)^2;  
R=(0.25)^2;  
 
 
 
% kalman algorithm ieration 
for n=1:199 
    
    Y(:,n+1)=A*Y(:,n);        %x(k+1|k) 
     
    C0=A*C0*A'+B*Q*B';       %p(k+1|k) 
     
    K=C0*H'*inv(H*C0*H'+R);    % Kg 
     
    Y(:,n+1)=Y(:,n+1)+K*(s(:,n+1)-H*Y(:,n+1));         %x(k|k) 
     
    C0=(eye(2,2)-K*H)*C0;      %p(k|k) 
                            
    
end 
 
% the diagram of position after filtering 
figure(3)  
t=0:0.1:19.9; 
yp=Y(1,:); 
plot(t,yp,'green'); 
axis([0 20 0 20]); 
xlabel('time'); 
ylabel('yp position'); 
title('the track after kalman filtering'); 
 
% the diagram of velocity after filtering 
figure(4)  
yv=Y(2,:); 
plot(t,yv,'red'); 
axis([0 20 -3 3]); 
xlabel('time'); 
ylabel('yv velocity'); 
title('the velocity caused by random acceleration'); 