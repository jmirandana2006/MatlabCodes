clear all, close all, clc
L=10;
T0=300;
CIchute_no_alvo=fzero(@bar_residuo,-50);%estimativa do chute inicial -50
[x,y]=ode45(@bar_temp,[0 L],[T0 CIchute_no_alvo]);
plot(x,y(:,1));
xlabel('x')
ylabel('y')
title('Distribui�ao de temperatura em um bastao aquecido')