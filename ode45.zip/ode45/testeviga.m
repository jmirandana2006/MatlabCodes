clear all, close all, clc
E=200e09;%constante elastica
I=30000*(1/100)^4;%segundo momento de inercia
W=15000;%carga
L=3;%comprimento total
y0=0;%condi�ao de fronteira para o ponto 0 
yL=0;%condi�ao de fronteira para o ponto L
inicial=[0 -1];%semente
[x1,y1]=ode45(@viga,[0 L],[y0 inicial(1)]);%resolvendo ED
chute1=y1(end,1);
[x2,y2]=ode45(@viga,[0 L],[y0 inicial(2)]);
chute2=y2(end,1);
chutes=[chute1 chute2];
novoCI=interp1(chutes,inicial,yL,'linear','extrap');
[x3,y3]=ode45(@viga,[0 L],[y0 novoCI]);
xx=linspace(0,L);
yanalitica = W/(24*E*I)*(2*L*xx.^3-xx.^4-L^3*xx);
figure
plot(xx,yanalitica,'b-',x3,y3(:,1),'ro')

