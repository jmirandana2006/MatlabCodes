clear all, close all, clc

intertempo=[0 1.5];
inicial=[0, 0];
[t,y]=ode45(@meued2nd1,intertempo,inicial);
plot(t,y(:,1)), title('y')
figure
plot(t,y(:,2)), title('velocidade')