function r=bar_res(CI_chute)
T0=300;
TL=400;
L=10;
[x,y]=ode45(@bar_temp,[0 L],[T0 CI_chute]);
r=y(end,1)-TL;