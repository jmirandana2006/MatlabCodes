clear all, close all, clc
t = 0:0.1:10;
y0=1;
n=5;
y_init = [y0*ones(n,1); zeros(n,1)];
[t,y] = ode45(@rhs1,t,y_init);
plot(t,y(:,2))