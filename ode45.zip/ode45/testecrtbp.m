G = 1;
m1 = 0.52; %solar mass
m2 = 0.33; %solar mass
r1= -21.3; %AU
r2= 33.7; %AU
ome=sqrt((m1+m2)/(-r1+r2)^3);
[t,x]=ode45(@crtbp,[0 35],[35;0;0;0.03]);
plot3(t,x(:,1),x(:,3))