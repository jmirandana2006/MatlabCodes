function result=viga(x,y)
E=200e09;
I=3e-4;
W=15000;
L=3;
% result=[y(2);1/(E*I)*((W*L*y(2)/2)-(W*y(2)^2)/2)];
result=[y(2);1/(E*I)*((W*L*x/2)-(W*x^2)/2)];

