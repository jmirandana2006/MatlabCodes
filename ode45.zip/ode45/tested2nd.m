clear all, close all, clc
tempo_periodo=[0 10];
inicial=[8, 21];
[t,y]=ode45(@ed2nd,tempo_periodo,inicial)
plot(t,y(:,1),'ko')
title('y')
grid on
figure
plot(t,y(:,2),'ro')
grid on
title('velocidade')
