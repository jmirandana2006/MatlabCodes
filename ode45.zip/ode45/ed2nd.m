function meuresult=ed2nd(t,y)
meuresult=[y(2);-5*y(2)-7];
