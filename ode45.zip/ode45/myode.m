function dydt = myode(t,y)
ft = linspace(0,5,25);
f = ft.^2 - ft - 3;
gt = linspace(1,6,25);
g = 3*sin(gt-0.25);

f = interp1(ft,f,t); % Interpolate the data set (ft,f) at time t
g = interp1(gt,g,t); % Interpolate the data set (gt,g) at time t
dydt = -f.*y + g; % Evaluate ODE at time t


