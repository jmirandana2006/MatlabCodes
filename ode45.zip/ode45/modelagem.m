% modeling data 
% sample number N=200 points 
% sample time T=0.1s 
 
t=0:0.1:20-0.1; 
T=0.1;            % sample time 
v=0.5;            % initial velocity 
y=ones(1,200); 
y(1)=0; 
for n=2:200; 
    y(n)=y(n-1)+v*T; 
end 
figure(1); 
plot(t,y,'-'); 
axis([0 20 0 20]); 
xlabel('time'); 
ylabel('yp position'); 
title('the initial track of movement'); 
 
% add white gauss noise 
a=0.5*randn(1,200); 
s=y+a;            %data+noise 
figure(2); 
plot(t,s,'blue'); 
axis([0 20 0 20]); 
xlabel('time'); 
ylabel('yp position'); 
title('the track of movement with noise'); 
 
save initial_track s 